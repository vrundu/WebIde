sap.ui.define([
	"com/probosys/SplitApp_Vr/test/unit/controller/DetailPage.controller"
], function () {
	"use strict";
});