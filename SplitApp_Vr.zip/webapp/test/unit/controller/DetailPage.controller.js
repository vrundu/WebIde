/*global QUnit*/

sap.ui.define([
	"com/probosys/SplitApp_Vr/controller/DetailPage.controller"
], function (Controller) {
	"use strict";

	QUnit.module("DetailPage Controller");

	QUnit.test("I should test the DetailPage controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});