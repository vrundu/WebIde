sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/Device"
], function (Controller, Device) {
	"use strict";

	return Controller.extend("com.menasha.zephyr.sop.ZLOAD3.controller.Home", {
		onInit: function () {
 if (!jQuery.support.touch) {
				this.getView().addStyleClass("sapUiSizeCompact");
			} else {
				this.getView().addStyleClass("sapUiSizeCompact");
			}
		}
	});
});