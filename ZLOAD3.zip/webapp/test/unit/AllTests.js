sap.ui.define([
	"com/menasha/zephyr/sop/ZLOAD3/test/unit/controller/Home.controller"
], function () {
	"use strict";
});