sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/Device",
	"jquery.sap.storage",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessagePopoverItem",
	"sap/m/MessagePopover",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/json/JSONModel"
], function (Controller, Device, jQuery, Dialog, Button, MessageBox, Filter, FilterOperator, MessagePopoverItem, MessagePopover,
	DateFormat,
	JSONModel) {
	"use strict";

	return Controller.extend("com.menasha.zephyr.sop.Z_WM_PICKING.controller.BaseController", {
		/* GET & SET USER NAME  */
		_readUser: function () {
			var that = this;
			var oModel = this.getOwnerComponent().getModel("UserSystemSet");
			/* CALL SERVICE FOR GET USER NAME     */
			//		oModel.read("/UserNameSet", {
			oModel.read("/UserNameSet", {
				context: true,
				async: false,
				success: function (oData) {
					that.getView().byId("lblUser").setText(oData.results[0].Lname + ", " + oData.results[0].Fname);
					setTimeout(function () {
						that.getView().byId("ShipmentInput").focus();
					}, 400);
				},
				error: function (oError) {
					setTimeout(function () {
						that.getView().byId("ShipmentInput").focus();
					}, 400);
					that.updateMessageStrip(sap.ui.core.MessageType.Error, JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		/* GET & SET SYSTEM NAME  */
		_readSystem: function () {
			// Set SYSTEMNAME
			var that = this;
			var oModel = this.getOwnerComponent().getModel("UserSystemSet");
			/* CALL SERVICE FOR GET SYSTEM NAME     */
			//	oModel.read("/SystemNameSet", {
			oModel.read("/SystemNameSet", {
				context: true,
				async: false,
				success: function (oData) {
					that.getView().byId("lblSystem").setText(oData.results[0].Sname);
					setTimeout(function () {
						that.getView().byId("ShipmentInput").focus();
					}, 400);
				},
				error: function (oError) {
					setTimeout(function () {
						that.getView().byId("ShipmentInput").focus();
					}, 400);
					that.updateMessageStrip(sap.ui.core.MessageType.Error, JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		_setTimer: function () {
			var controller = this;
			setInterval(function () {
				var currDateObj = new Date();
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM/dd/yyyy"
				});
				//Final Date to show on the bar
				var finalDate = oDateFormat.format(new Date(currDateObj.getTime()));
				//Hours and minutes
				var hrs = currDateObj.getHours().toString();
				var min = currDateObj.getMinutes().toString();
				var sec = currDateObj.getSeconds().toString();
				var finalTime;
				if (min < 10) {
					//Concatenate 0
					min = "0" + min;
				}
				if (sec < 10) {
					//Concatenate 0
					sec = "0" + sec;
				}
				//AM or PM
				var finalTimeAMPM = "PM";
				if (hrs >= 12) {
					finalTimeAMPM = "PM";
				} else {
					finalTimeAMPM = "AM";
				}
				//Converting to AM PM format
				if (hrs > 12) {
					hrs = hrs - 12;
					finalTime = hrs + ":" + min + ":" + sec + " " + finalTimeAMPM;
				} else {
					finalTime = hrs + ":" + min + ":" + sec + " " + finalTimeAMPM;
				}
				if (controller.getView().byId("lblDateTime") !== undefined) {
					controller.getView().byId("lblDateTime").setText(finalDate + " " + finalTime);
				}
			}, 400);
		},
		setMenashaImage: function () {
			var oRootPath = jQuery.sap.getModulePath("com.menasha.zephyr.sop.Z_WM_PICKING.images");
			var oImageModel = new sap.ui.model.json.JSONModel({
				path: oRootPath
			});
			this.getView().setModel(oImageModel, "imageModel");
		},
		hideMessageStrip: function () {
			var oMsgStrip = this.getView().byId("MessageStripID");
			if (oMsgStrip.getVisible()) {
				oMsgStrip.setVisible(false);
			}
			var oMsgStrip1 = this.getView().byId("MessageStripID1");
			if (oMsgStrip1.getVisible()) {
				oMsgStrip1.setVisible(false);
			}
			/*var oMsgStrip2 = this.getView().byId("MessageStripID2");
			if (oMsgStrip2.getVisible()) {
				oMsgStrip2.setVisible(false);
			}*/
		},

		/* INITIALIZE POPOVER  */
		initialMessagePopover: function () {
			var that = this;
			var oMessageTemplate = new MessagePopoverItem({
				type: "{type}",
				title: "{title}",
				description: "{description}",
				subtitle: "{subtitle}"
			});
			this.oMessagePopover = new MessagePopover({
				items: {
					path: "/",
					template: oMessageTemplate
				}
			});
		},
		/* SET ERROR LIST   */
		setListOfErrorMessagesModel: function () {
			var ListOfErrorMessagesModel = new JSONModel();
			if (jQuery.sap.storage(jQuery.sap.storage.Type.session).get("ListOfErrorMessagesModel") === null) {
				ListOfErrorMessagesModel = new JSONModel();
				ListOfErrorMessagesModel.setData([]);
				this.oMessagePopover.setModel(ListOfErrorMessagesModel);
			} else {
				var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				var oModel = JSON.parse(oStorage.get("ListOfErrorMessagesModel"));
				ListOfErrorMessagesModel = new JSONModel();
				ListOfErrorMessagesModel.setData(
					oModel
				);
				this.oMessagePopover.setModel(ListOfErrorMessagesModel);
				//Set Count
				var errorCount = new JSONModel();
				errorCount.setData({
					messageLength: oModel.length + ''
				});
				this.getView().setModel(errorCount, "errorCount");
			}
		},

		onMessagePopoverPress: function (oEvent) {
			if (!this.oMessagePopover.isOpen()) {
				this.oMessagePopover.openBy(oEvent.getSource());
			} else {
				this.oMessagePopover.close();
			}
		},

		getResourceBundle: function (oEvent) {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		onFocus: function (id) {
			var that = this;
			setTimeout(function () {
				that.getView().byId(id).focus();
			}, 500);
		},

		/*  CREATE ERROR MESSAGE  */
		createNewErrorLog: function (oError, titleName) {
			var aMockMessages = this.oMessagePopover.getModel().getData();
			var ShipmentMsg = this.getResourceBundle().getText("Shipment");
			var description = "";
			if (oError === "HU") {
				description = this.getResourceBundle().getText("HUMandatory"); // Handling Unit is Mandatory";
			} else if (oError === "Same-HU") {
				description = this.getResourceBundle().getText("BothHuCntSame"); //"Both HU's cannot be same";
			} else if (oError === "Shipment") {
				description = this.getResourceBundle().getText("ShipMandatory"); ///"Work Center is Mandatory";
			} else if (oError === "SCAN-DOOR") {
				description = this.getResourceBundle().getText("DoorMandatory"); //"Work Center or Material is Mandatory";
			} else if (oError === "Post Error Pick") {
				description = titleName;
			} else if (titleName === "PrintPickList") {
				titleName = ShipmentMsg+" "+this.byId("ShipmentInput").getValue();
				try {
					description = JSON.parse(oError.responseText).error.message.value;
				} catch (ex) {
					description = oError.message;
				}
				oError = "PrintPickList";
			} else {
				try {
					description = JSON.parse(oError.responseText).error.message.value;
				} catch (ex) {
					description = oError.message;
				}
			}
			aMockMessages.unshift({
				type: "Error",
				title: titleName,
				description: description + "  \n " + this.getTimestamp(),
				markupDescription: false,
				subtitle: description,
				counter: 1
			});
			var ListOfErrorMessagesModel = new JSONModel();
			ListOfErrorMessagesModel.setData(aMockMessages);
			this.oMessagePopover.setModel(ListOfErrorMessagesModel);
			var errorCount = new JSONModel();
			errorCount.setData({
				messagesLength: aMockMessages.length + ''
			});
			this.getView().setModel(errorCount, "errorCount");
			if (oError !== "Post Error Pick" && oError !== "PrintPickList") {
				this.updateMessageStrip(sap.ui.core.MessageType.Error, description);
			} else if (oError === "PrintPickList") {
				this.updateMessageStrip("PrintError", description);
			}
		},
		getTimestamp: function () {
			var oReturnDate;
			var date = new Date();
			var oLocale = new sap.ui.core.Locale("en-US");
			var oFormatOptions = {
				pattern: "MMM, dd YYYY hh:mm:ss"
			};
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance(oFormatOptions, oLocale);
			if (date.getHours() < 12) {
				oReturnDate = oDateFormat.format(date) + " AM";
			} else {
				oReturnDate = oDateFormat.format(date) + " PM";
			}
			return oReturnDate;
		},
		onColumnSelection: function (event) {
			var that = this;
			var List = that.byId("List");
			var column = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("Columns");
			var ok = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("OK");
			var Cancel = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("Cancel");
			var popOver = this.byId("popOver");
			if (List !== undefined) {
				List.destroy();
			}
			if (popOver !== undefined) {
				popOver.destroy();
			}
			/*----- PopOver on Clicking ------ */
			var popover = new sap.m.Dialog(this.createId("popOver"), {
				showHeader: true,
				title: column,
				placement: sap.m.PlacementType.Bottom,
				content: [],

				beginButton: new sap.m.Button({
					text: ok,
					press: function () {
						that.onSave();
					}
				}),
				endButton: new sap.m.Button({
					text: Cancel,
					press: function () {
						popover.close();
					}
				}),
				subHeader: [
					new sap.m.Bar({
						contentMiddle: [
							new sap.m.SearchField({
								width: "100%",
								search: function (evt) {
									that.onSearch(evt);
								}

							})
						]
					})
				]
			}).addStyleClass("sapMOTAPopover sapTntToolHeaderPopover");
			/*----- Adding List to the PopOver -----*/
			var oList = new sap.m.List(this.createId("List"), {});
			this.byId("popOver").addContent(oList);
			var openAssetTable = this.getView().byId("table"),
				columnHeader = openAssetTable.getColumns();
			var openAssetColumns = [];
			for (var i = 0; i < columnHeader.length; i++) {
				var hText = columnHeader[i].getLabel().getProperty("text");
				var columnObject = {};
				columnObject.column = hText;
				openAssetColumns.push(columnObject);

			}
			var oModel1 = new sap.ui.model.json.JSONModel({
				list: openAssetColumns
			});
			var itemTemplate = new sap.m.StandardListItem({
				title: "{oList>column}"
			});
			oList.setMode("MultiSelect");
			oList.setModel(oModel1);
			sap.ui.getCore().setModel(oModel1, "oList");
			var oBindingInfo = {
				path: 'oList>/list',
				template: itemTemplate
			};
			oList.bindItems(oBindingInfo);
			var footer = new sap.m.Bar({
				contentLeft: [],
				contentMiddle: [
					new sap.m.Button({
						text: "Set",
						press: function () {
							that.onSave();
						}
					})
				]
			});
			//	this.byId("popOver").setFooter(footer);
			var oList1 = this.byId("List");
			var table = this.byId("table").getColumns();
			oList1.attachEventOnce("updateFinished", function () {
				var a = [];
				for (var j = 0; j < table.length; j++) {
					var list = oList1.oModels.undefined.oData.list[j].column;
					a.push(list);
					var Text = table[j].getLabel().getProperty("text");
					var v = table[j].getProperty("visible");
					if (v === true) {
						if (a.indexOf(Text) > -1) {
							var firstItem = oList1.getItems()[j];
							oList1.setSelectedItem(firstItem, true);
						}
					}
				}
			});
			popover.open(event.getSource());
		},
		onSearch: function (oEvent) {
			var sFilterText = oEvent.getParameter("query");
			var data = this.getView().byId("List").getBinding("items");
			var oFilter = new Filter("column", sap.ui.model.FilterOperator.Contains, sFilterText);
			data.filter([oFilter]);
		},
		onSave: function () {
			var that = this;
			var oList = this.byId("List");
			var array = [];
			var items = oList.getSelectedItems();

			// Getting the Selected Columns header Text.
			for (var i = 0; i < items.length; i++) {
				var item = items[i];
				var context = item.getBindingContext("oList");
				var obj = context.getProperty(null, context);
				var column = obj.column;
				array.push(column);

			}
			var table = this.byId("table").getColumns();
			for (var j = 0; j < table.length; j++) {
				var Text = table[j].getLabel().getProperty("text");
				var Column = table[j].getId();
				var columnId = this.getView().byId(Column);
				if (array.indexOf(Text) > -1) {
					columnId.setVisible(true);
				} else {
					columnId.setVisible(false);
				}
			}
			this.byId("popOver").close();

		},
		/*onParseValue: function (oEvent) {
			if (oEvent === null || oEvent === "") {
				return "";
			} else {
				return parseInt(oEvent);
			}
		},*/
		onValidateScanDoor: function (oEvent) {
			var door = this.getView().byId("scanDoorInput_1").getValue().trim();
			if (door === "") {
				this.getView().byId("Pick").setEnabled(false);
			} else {
				this.getView().byId("Pick").setEnabled(true);
			}
		},
		updateMessageStrip: function (msgType, text) {
			if (msgType === "") {
				var oMsgStrip1 = this.getView().byId("MessageStripID1");
				if (!oMsgStrip1.getVisible()) {
					oMsgStrip1.setVisible(true);
				}
				oMsgStrip1.setType(sap.ui.core.MessageType.Error);
				oMsgStrip1.setText(text);
			} else if (msgType === "Print") {
				var oMsgStrip2 = this.getView().byId("MessageStripID1");
				if (!oMsgStrip2.getVisible()) {
					oMsgStrip2.setVisible(true);
				}
				oMsgStrip2.setType(sap.ui.core.MessageType.Success);
				oMsgStrip2.setText(text);
			} else if (msgType === "PrintError") {
				var oMsgStrip2 = this.getView().byId("MessageStripID1");
				if (!oMsgStrip2.getVisible()) {
					oMsgStrip2.setVisible(true);
				}
				oMsgStrip2.setType(sap.ui.core.MessageType.Error);
				oMsgStrip2.setText(text);
			} else {
				var oMsgStrip = this.getView().byId("MessageStripID");
				if (!oMsgStrip.getVisible()) {
					oMsgStrip.setVisible(true);
				}
				oMsgStrip.setType(msgType);
				oMsgStrip.setText(text);
			}
		},

		onClear: function (mode) {
			var that = this;
			if (mode === "hu") {
				that.hideMessageStrip();
				//this.getView().byId("LineInput").setEnabled(true);
				this.getView().byId("DoorInput").setEnabled(true);
				that.getView().byId("ScacInput").setEnabled(true);
				this.getView().byId("SealInput").setEnabled(true);
				this.getView().byId("TrailerInput").setEnabled(true);
				this.getView().byId("UnloadHU").setEnabled(true);
				this.getView().byId("CreateTo").setEnabled(true);
				this.getView().byId("UpdateShipment").setEnabled(true);
				this.getView().byId("CloseTrailer").setEnabled(true);
				this.getView().byId("PrintPickList").setEnabled(true);
				this.getView().byId("HUInput_0").setEnabled(true);
				that.getView().byId("refreshShipment").setEnabled(true);
				that.onFocus("HUInput_0");
			}
			if (mode !== "onPick" && mode !== "hu") {
				this.getView().byId("ShipmentInput").setValue("");
				this.getView().byId("ShipmentInput").setEnabled(true);
				//this.getView().byId("LineInput").setValue("");
				//this.getView().byId("LineInput").setEnabled(false);
				this.getView().byId("DoorInput").setValue("");
				this.getView().byId("DoorInput").setEnabled(false);
				this.getView().byId("ScacInput").setValue("");
				that.getView().byId("ScacInput").setEnabled(false);
				this.getView().byId("SealInput").setValue("");
				this.getView().byId("SealInput").setEnabled(false);
				this.getView().byId("CarrierText").setText("");
				this.getView().byId("TrailerInput").setValue("");
				this.getView().byId("TrailerInput").setEnabled(false);
				this.getView().byId("UnloadHU").setEnabled(false);
				//this.getView().byId("PrintPickList").setEnabled(false);
				this.getView().byId("CreateTo").setEnabled(false);
				this.getView().byId("UpdateShipment").setEnabled(false);
				this.getView().byId("CloseTrailer").setEnabled(false);
				this.getView().byId("HUInput_0").setEnabled(false);
				this.getView().byId("HUInput_1").setEnabled(false);
				this.getView().byId("huTable").setVisible(false);
				
				that.getView().byId("ShipmentText").setText("");
				that.getView().byId("ShipmentText2").setText("");

				that.getView().byId("ShipmentInput").setValueState("None");
				that.getView().byId("HUInput_0").setValueState("None");
				that.getView().byId("HUInput_1").setValueState("None");
				
				that.getView().byId("refreshShipment").setEnabled(false);
			}

			if (mode === "clear") {
				that.hideMessageStrip();
				this.getView().byId("PrintPickList").setEnabled(false);
				that.getView().byId("printPicklist2").setEnabled(false);
				that.getView().byId("searchField").setVisible(false);

				if (that.getView().getModel("PicklistLodModel"))
					that.getView().getModel("PicklistLodModel").setData([]);

				if (that.getView().getModel("delData"))
					that.getView().getModel("delData").setData([]);

				that.onFocus("ShipmentInput");
			} else if (mode === "closeTrailer") {
				that.getView().byId("ShipmentInput").setValueState("Error");
				that.onFocus("ShipmentInput");
			}
			
				this.getView().byId("HUInput_0").setEnabled(true);
				this.getView().byId("HUInput_1").setEnabled(false);
				this.getView().byId("scanDoorInput_1").setEnabled(false);
				that.getView().byId("scanDoorInput_1").setValue("");
				this.getView().byId("Pick").setEnabled(false);
				this.getView().byId("HUInput_0").setValue("");
				this.getView().byId("HUInput_1").setValue("");
				this.getView().byId("maxInput_0").setValue("");
				this.getView().byId("maxInput_1").setValue("");
				this.getView().byId("topickInput_0").setValue("");
				this.getView().byId("topickInput_1").setValue("");
				this.getView().byId("MaterialInput_0").setValue("");
				this.getView().byId("MaterialInput_1").setValue("");
				this.getView().byId("batchInput_0").setValue("");
				this.getView().byId("batchInput_1").setValue("");
				this.getView().byId("qtyInput_0").setValue("");
				this.getView().byId("qtyInput_1").setValue("");
				that.getView().byId("HUInput_0").setValueState("None");
				that.getView().byId("HUInput_1").setValueState("None");
		},
		/*  DISPLAY SUCCESS MESSAGE HERE  */
		updatePostingList: function (log, Quantity, TO, Delivery) {
			var that = this;
			var items = this.getView().byId("postList").getModel("successfulPostsModel").getData().items;
			if (log !== "" && Quantity === "" && TO === "" && Delivery === "") {
				items.unshift({
					"Timestamp": this.getTimestamp(),
					"log": log,
				});
			//	successMsg = log1 + " " + log2;
			} else {
				if(Delivery === ""){
					items.unshift({
						//"Timestamp": this.getTimestamp(),
					"log": log,
					"Quantity": "Qty: " + Quantity,
					"TO": "TO: " + TO
					});	
				}
				else{
					items.unshift({
						//"Timestamp": this.getTimestamp(),
					"log": log,
					"Quantity": "Qty: " + Quantity,
					"TO": "TO: " + TO,
					"Delivery": "Delivery: " + Delivery,
					});
				}
				
			//	successMsg = log1;
			}

			/*  ADD DATA TO SUCCESS MODEL    */
			var successfulPostsModel = new JSONModel(items, true);
			successfulPostsModel.setData({
				items: items
			});
			this.getView().byId("postList").setModel(successfulPostsModel, "successfulPostsModel");
			//	this.updateMessageStrip(sap.ui.core.MessageType.Success, successMsg);
		//	this.getView().byId("splitterLayoutData").setSize("24%");
		//	this.getView().byId("splitterLayoutData1").setSize("0%");
		//	this.getView().byId("idPostsToggle").setIcon("sap-icon://open-command-field");
		},
		setSuccessfulPostsModel: function () {
			/*var successfulPostsModel = new JSONModel();
			successfulPostsModel.setData({
				items: []
			});
			this.getView().byId("postList").setModel(successfulPostsModel, "successfulPostsModel");*/
			var successfulPostsModel = new JSONModel();
			if (jQuery.sap.storage(jQuery.sap.storage.Type.session).get("successfulPostsModel") === null) {
				successfulPostsModel = new JSONModel();
				successfulPostsModel.setData({
					items: []
				});
				this.getView().byId("postList").setModel(successfulPostsModel, "successfulPostsModel");
			} else {
				var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				var oModel = JSON.parse(oStorage.get("successfulPostsModel"));
				successfulPostsModel = new JSONModel();
				successfulPostsModel.setData(
					oModel
				);
				this.getView().byId("postList").setModel(successfulPostsModel, "successfulPostsModel");
			}

		},
	});
});