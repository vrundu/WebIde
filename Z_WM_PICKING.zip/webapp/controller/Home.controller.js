sap.ui.define([
	"./BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/Device",
	"jquery.sap.storage",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessagePopoverItem",
	"sap/m/MessagePopover",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/json/JSONModel"
], function (BaseController, Controller, Device, jQuery, Dialog, Button, MessageBox, Filter, FilterOperator, MessagePopoverItem,
	MessagePopover, DateFormat, JSONModel) {
	"use strict";

	return BaseController.extend("com.menasha.zephyr.sop.Z_WM_PICKING.controller.Home", {

		onInit: function () {
			var that = this;
			if (!jQuery.support.touch) {
				this.getView().addStyleClass("sapUiSizeCompact");
			} else {
				this.getView().addStyleClass("sapUiSizeCompact");
			}

			/* INITIALIZE POPOVER  */
			this.initialMessagePopover();

			/* SET ERROR LIST   */
			this.setListOfErrorMessagesModel();

			/* SET TIMER   */
			this._setTimer();

			/* SET USER NAME  */
			this._readUser();

			/* SET SYSTEM NAME */
			this._readSystem();

			this.setMenashaImage();

			this.setSuccessfulPostsModel();

		},
		onPostsToggle: function () {
			if (this.getView().byId("splitterLayoutData").getSize() === "0%") {
				this.getView().byId("splitterLayoutData").setSize("24%");
				this.getView().byId("idPostsToggle").setIcon("sap-icon://open-command-field");
				if (this.getView().byId("splitterLayoutData1").getSize() === "31%") {
				//	this.getView().byId("splitterLayoutData1").setSize("0%");
					//this.getView().byId("idPostsToggle1").setIcon("sap-icon://open-command-field");
				//	this.getView().byId("idPostsToggle1").removeStyleClass("sapUiLargeMarginBegin");
				}
			} else {
				this.getView().byId("splitterLayoutData").setSize("0%");
				this.getView().byId("idPostsToggle").setIcon("sap-icon://close-command-field");
				this.getView().byId("idPostsToggle").removeStyleClass("sapUiLargeMarginEnd");
			}
		},
		onPostsToggle1: function () {
			if (this.getView().byId("splitterLayoutData1").getSize() === "31%") {
				this.getView().byId("splitterLayoutData1").setSize("0%");
				//this.getView().byId("idPostsToggle1").setIcon("sap-icon://open-command-field");
				this.getView().byId("idPostsToggle1").removeStyleClass("sapUiLargeMarginBegin");
			} else {
				if (!jQuery.support.touch) {
					this.getView().byId("splitterLayoutData1").setSize("31%");
				} else {
					this.getView().byId("splitterLayoutData1").setSize("31%");
				}
				//this.getView().byId("idPostsToggle1").setIcon("sap-icon://close-command-field");

				if (this.getView().byId("splitterLayoutData").getSize() === "24%") {
				//	this.getView().byId("splitterLayoutData").setSize("0%");
				//	this.getView().byId("idPostsToggle").setIcon("sap-icon://close-command-field");
				//	this.getView().byId("idPostsToggle").removeStyleClass("sapUiLargeMarginEnd");
				}

			}
		},
		onPress: function (oEvent) {
			var that = this;
			var key = oEvent.getParameters().key;
			if (key == 'info') {
				this.getView().byId("splitterLayoutData1").setSize("31%");
				this.getView().byId("idPostsToggle1").setVisible(true);
				this.getView().byId("ShpmntLbl").setVisible(true);
				this.getView().byId("ShipmentText").setVisible(true);
				//	this.getView().byId("idPostsToggle1").setIcon("sap-icon://close-command-field");
				//	that.hideMessageStrip();

			} else if (key == 'Picklist') {
				this.getView().byId("splitterLayoutData1").setSize("0%");
				this.getView().byId("idPostsToggle1").setVisible(false);
				this.getView().byId("ShpmntLbl").setVisible(false);
				this.getView().byId("ShipmentText").setVisible(false);
				var shipment = this.getView().byId("ShipmentText2").getText().trim();
				var ShipmentMsg = this.getResourceBundle().getText("Shipment");
				if (shipment !== "") {

					var oMsgStrip2 = this.getView().byId("MessageStripID1");
					if (oMsgStrip2.getVisible()) {
						oMsgStrip2.setVisible(false);
					}
					var picklistModel = that.getView().getModel("PicklistLodModel");
					picklistModel = new JSONModel();
					that.getView().setModel(picklistModel, "PicklistLodModel");
					var oSmartTable = this.byId("table");

					//oSmartTable.rebindTable();
					var oModel = this.getView().getModel("shipmentModel");
					var Hudata = new sap.ui.model.json.JSONModel();
					var oFilter = new Filter("Shpmnt", "EQ", shipment);
					sap.ui.core.BusyIndicator.show();
					oModel.read("/PickListSet", {
						context: true,
						filters: [oFilter],
						async: false,
						success: function (oData) {
							sap.ui.core.BusyIndicator.hide(0);
							picklistModel.setData(oData.results);
							that.getView().setModel(picklistModel, "PicklistLodModel");
							that.getView().getModel("PicklistLodModel").refresh();
							that.getView().byId("PickerName").setText(oData.results[0].PickerName);

							var currDateObj = new Date(oData.results[0].Date);
							var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
								pattern: "MM/dd/yyyy"
							});
							//Final Date to show on the bar
							var finalDate = oDateFormat.format(new Date(currDateObj.getTime()));

							that.getView().byId("PickerDate").setText(finalDate);
						},
						error: function (oError) {
							sap.ui.core.BusyIndicator.hide(0);
							that.createNewErrorLog(oError, ShipmentMsg + " : " + shipment);
						}
					});
				}
			}
		},
		onUnloadHU: function () {
			var that = this;
			var selectedDelivery = this.getView().byId("huTable").getSelectedItem();
			var UnloadMsg = this.getResourceBundle().getText("UnloadHU");
			var SelectOneDlvryMsg = this.getResourceBundle().getText("SelectOneDlvry");
			//this.getResourceBundle().getText("worklistTableTitle");
			if (selectedDelivery !== null) {
				if (selectedDelivery.getCells()[0].getText().includes(" -")) {
					that.hideMessageStrip();
					var DeliveryNo = selectedDelivery.getCells()[0].getText().split("-")[0].trim();
					//	var ItemNo = selectedDelivery.getCells()[0].getText().split("-")[1].trim();
					var itemData = selectedDelivery.getCells()[0].getText().split("-")[1].trim();
					var ItemNo = itemData.split(" ")[0].trim();
					var shipment = this.getView().byId("ShipmentInput").getValue().trim();
					var Hudata = new sap.ui.model.json.JSONModel();
					var oModel = this.getView().getModel("shipmentModel");
					var oFilter = new Filter("Delivery", "EQ", DeliveryNo);
					var oFilter1 = new Filter("Item", "EQ", ItemNo);
					this.oHULodVHD = sap.ui.xmlfragment("com.menasha.zephyr.sop.Z_WM_PICKING.view.ValueHelpDialog.HuLoaded", this);
					this.getView().addDependent(this.oHULodVHD);
					sap.ui.core.BusyIndicator.show();
					oModel.read("/HuListSet", {
						context: true,
						filters: [oFilter, oFilter1],
						async: false,
						success: function (oData) {
							sap.ui.core.BusyIndicator.hide(0);
							Hudata.setData(oData.results);
							sap.ui.getCore().setModel(Hudata, "HULodModel");
							sap.ui.getCore().getModel("HULodModel").refresh();
							that.getView().addDependent(that.pressDialog);
							that.oHULodVHD.setModel(Hudata, "HULodModel");
							that.getView().addDependent(that.oHULodVHD);
							that.oHULodVHD.open();
							that.onFocus("HUInput_0");
						},
						error: function (oError) {
							sap.ui.core.BusyIndicator.hide(0);
							that.createNewErrorLog(oError, UnloadMsg + " : " + DeliveryNo + " - " + ItemNo);
							that.onFocus("HUInput_0");
						}
					});
				} else {
					MessageBox.warning(SelectOneDlvryMsg);
				}
			} else {
				MessageBox.warning(SelectOneDlvryMsg);
			}
		},

		onHUDel: function (oEvent) {
			var that = this;
			var oModel = this.getView().getModel("shipmentModel");
			var SelectOneRcrdMsg = this.getResourceBundle().getText("SelectOneRcrd");
			var HuUnasgnMsg = this.getResourceBundle().getText("HuUnasgn");
			var HUDelMsg = this.getResourceBundle().getText("HUDel");
			var oPayload = {};
			if (sap.ui.getCore().byId("HULodTable").getSelectedItem() === null) {
				MessageBox.warning(SelectOneRcrdMsg);
				return;
			} else {

				that.hideMessageStrip();
				var selectHU = sap.ui.getCore().byId("HULodTable").getSelectedItem().getTitle();
				oPayload.Exidv = selectHU;
				sap.ui.core.BusyIndicator.show();
				oModel.update("/HuListSet(Exidv='" + selectHU + "')", oPayload, {
					method: "PUT",
					success: function (oData, response) {
						sap.ui.core.BusyIndicator.hide(0);
						var successMsg = HuUnasgnMsg;
						if (response.statusCode === "204") {
							that.onInputShipmentSubmit();
							that.updateMessageStrip(sap.ui.core.MessageType.Success, successMsg);
							that.updatePostingList(successMsg, "", "", "");
						}
						that.onFocus("HUInput_0");
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide(0);
						that.createNewErrorLog(oError, HUDelMsg + " : " + selectHU);
						that.onFocus("HUInput_0");
					}
				});
				this.oHULodVHD.close();
				this.oHULodVHD.destroy();
			}
		},
		onClose2: function () {
			this.oHULodVHD.close();
			this.oHULodVHD.destroy();
		},
		onInputShipmentSubmit: function (oEvent) {
			var that = this;
			var ShipmentMsg = this.getResourceBundle().getText("Shipment");
			var shipment = this.getView().byId("ShipmentInput").getValue().trim();
			var hu = this.getView().byId("HUInput_0").getValue().trim();
			that.getView().byId("ShipmentInput").setValueState("None");
			if (shipment === "") {
				that.createNewErrorLog("Shipment", "Shipment: ");
				that.getView().byId("ShipmentInput").setValueState("Error");
				that.onFocus("ShipmentInput");

			} else {
				var oModel = this.getView().getModel("shipmentModel");
				if (oEvent) {
					that.hideMessageStrip();
				}
				var oFilter = new Filter("Shpmnt", "EQ", shipment);
				sap.ui.core.BusyIndicator.show();
				oModel.read("/ShipmentSet", {
					context: true,
					filters: [oFilter],
					async: false,
					urlParameters: "&$expand=ToDelivItem/ToToItem",
					success: function (oData) {
						sap.ui.core.BusyIndicator.hide(0);
						//	MessageBox.show(JSON.stringify(oData));
						that.getView().byId("ShipmentInput").setValueState("None");
						var ShpmntData = oData.results;
						that.getView().byId("ShipmentInput").setValue(oData.results[0].Shpmnt);
						that.getView().byId("ScacInput").setValue(oData.results[0].Scacd);
						that.getView().byId("SealInput").setValue(oData.results[0].Seal);
						that.getView().byId("DoorInput").setValue(oData.results[0].Signi);
						that.getView().byId("TrailerInput").setValue(oData.results[0].Trailer);
						that.getView().byId("CarrierText").setText(oData.results[0].Vendor);

						that.getView().byId("ShipmentText").setText(oData.results[0].Shpmnt);
						that.getView().byId("ShipmentText2").setText(oData.results[0].Shpmnt);
						that.getView().byId("printPicklist2").setEnabled(true);
						//that.getView().byId("LineInput").setEnabled(true);
						that.getView().byId("SealInput").setEnabled(true);
						that.getView().byId("TrailerInput").setEnabled(true);
						that.getView().byId("ScacInput").setEnabled(true);

						that.getView().byId("ShipmentInput").setEnabled(false);
						that.getView().byId("DoorInput").setEnabled(true);
						that.getView().byId("HUInput_0").setEnabled(true);
						that.getView().byId("UnloadHU").setEnabled(true);
						that.getView().byId("PrintPickList").setEnabled(true);
						that.getView().byId("CreateTo").setEnabled(true);
						that.getView().byId("UpdateShipment").setEnabled(true);
						that.getView().byId("CloseTrailer").setEnabled(true);
						that.getView().byId("Clear").setEnabled(true);
						that.getView().byId("huTable").setVisible(true);
						that.getView().byId("searchField").setVisible(true);
						that.getView().byId("refreshShipment").setEnabled(true);
						
						that.onFocus("HUInput_0");

						var oDelvModel = new sap.ui.model.json.JSONModel();
						var ShipmentDataModel = new sap.ui.model.json.JSONModel();
						var oDelvArr = [];
						var oDelvObj = {};
						var devData = {};
						that.oTODATA = [];
						var arr1 = [], arr2 = [];
						ShpmntData = oData.results;
						ShipmentDataModel.setData(oData.results);
						that.getView().setModel(ShipmentDataModel, "ShipmentDataModel");

						for (var i = 0; i < ShpmntData.length; i++) {
							var oDelItem = ShpmntData[i].ToDelivItem.results;
							for (var j = 0; j < oDelItem.length; j++) {
								var ToToItem = oDelItem[j].ToToItem.results;
									var oToDelivItem = oDelItem[j];
									var Items = oToDelivItem.Item;
									var Delivery = oToDelivItem.Delivery;
									var material = oToDelivItem.Material;
									var custmat = "\u00a0\t\u00a0\t" + oToDelivItem.Custmat;
									var Matdesc = oToDelivItem.Matdesc;
									var Quantity = oToDelivItem.Qty;
									var Qtyuom = oToDelivItem.Qtyuom;
									var oDelvObj0 = {
										"Delivery": Delivery + " - " + parseInt(Items),
										"Tanum": Delivery + " -" + parseInt(Items),
										"Vlenr": "\u00a0\t\u00a0\t" + Quantity + " " + Qtyuom,
										"Vsolm": custmat,
										"Meins": "",
										"Pquit": false
									};
									oDelvArr.push(oDelvObj0);
									var oDelvObj1 = {
										"Delivery": Delivery + " - " + parseInt(Items),
										"Tanum": "",
										"Vlenr": material + "    \u00a0\t\u00a0\t",
										"Vsolm": Matdesc,
										"Tapos": "",
										"Pquit": false
									};
									oDelvArr.push(oDelvObj1);
									
									arr1.push(oDelvObj0);
									arr2.push(oDelvObj1);
							/*	for (var k = 0; k < 1; k++) {
								
								}*/
								for (var m = 0; m < ToToItem.length; m++) {

									oDelvObj.Delivery = ToToItem[m].Delivery + " - " + parseInt(ToToItem[m].Item);
									oDelvObj.Tanum = parseInt(ToToItem[m].Tanum) + "    " + "\u00a0\t\u00a0\t";
									oDelvObj.Vlenr = ToToItem[m].Vlenr + "    " + "\u00a0\t\u00a0\t";
									oDelvObj.Vsolm = ToToItem[m].Vsolm + "    " + "\u00a0\t\u00a0\t";
									oDelvObj.Meins = ToToItem[m].Meins + "    " + "\u00a0\t\u00a0\t";
									oDelvObj.Charg = ToToItem[m].Charg + "    " + "\u00a0\t\u00a0\t";
									oDelvObj.Pquit = ToToItem[m].Pquit;
									oDelvArr.push(oDelvObj);
									oDelvObj = {};

									that.oTODATA.push({
										"HU": ToToItem[m].Vlenr,
										"TO": ToToItem[m].Tanum
									});
										arr2.push(oDelvObj1);
								}
								arr1.push({"results":arr2});
							}
							devData.results = arr1;
						}
					//	oDelvModel.setData(oDelvArr);
						// set the model to the tree

							MessageBox.show(JSON.stringify(devData));
						that.getView().byId("huTable").setModel(oDelvModel, "delData");
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide(0);
						that.createNewErrorLog(oError, ShipmentMsg + " : " + shipment);
						that.getView().byId("ShipmentInput").setValueState("Error");
						that.onFocus("ShipmentInput");
					}
				});
			}
		},
		onCreateTo: function (oEvent) {
			var that = this;
			var oPayload = {};
			var CreateToMsg = this.getResourceBundle().getText("CreateTo");
			var oModel = this.getView().getModel("shipmentModel");
			var shipment = that.byId("ShipmentInput").getValue();
			var selectedDelivery = this.getView().byId("huTable").getSelectedItem();
			var delivery = "";
			var item = "";
			if (selectedDelivery !== null) {
				if (selectedDelivery.getCells()[0].getText().includes(" -")) {
					delivery = selectedDelivery.getCells()[0].getText().split("-")[0].trim();
					var itemData = selectedDelivery.getCells()[0].getText().split("-")[1].trim();
					item = itemData.split(" ")[0].trim();
				} else {
					delivery = "";
					item = "";
				}
			} else {
				delivery = "";
				item = "";
			}
			oPayload.Delivery = delivery;
			oPayload.Item = item;
			oPayload.Shpmnt = that.byId("ShipmentInput").getValue();
			that.hideMessageStrip();
			sap.ui.core.BusyIndicator.show();
			oModel.create("/CreateToSet", oPayload, {
				method: "POST",
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide(0);
					if (oData.Popup === "Y") {
						MessageBox.show(
							oData.Log, {
								icon: sap.m.MessageBox.Icon.WARNING,
								title: "Warning",
								actions: [MessageBox.Action.YES, MessageBox.Action.NO],
								onClose: function (oAction) {
									if (oAction === 'YES') {
										oData.Popup = "X";
										sap.ui.core.BusyIndicator.show();
										oModel.create("/CreateToSet", oData, {
											method: "POST",
											success: function (oData1, response1) {
												sap.ui.core.BusyIndicator.hide(0);
												that.onInputShipmentSubmit();
												that.updatePostingList(oData1.Log, "", "", "");
												that.updateMessageStrip(sap.ui.core.MessageType.Success, oData1.Log);
											},
											error: function (oError1) {
												sap.ui.core.BusyIndicator.hide(0);
												that.createNewErrorLog(oError1, CreateToMsg + " : " + shipment + " - " + delivery);
												that.onFocus("HUInput_0");
											}

										});
									}
								}
							});

					} else {
						that.onInputShipmentSubmit();
						that.updatePostingList(oData.Log, "", "", "");
						that.updateMessageStrip(sap.ui.core.MessageType.Success, oData.Log);
						that.onFocus("HUInput_0");
					}
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide(0);
					that.createNewErrorLog(oError, CreateToMsg + " : " + shipment + " - " + delivery);
					that.onFocus("HUInput_0");
				}
			});

		},
		onUpdateShipment: function (oEvent) {
			var that = this;
			var status = "";
			var successMsg = "";
			var ShipmentMsg = this.getResourceBundle().getText("Shipment");
			var UpdatedMsg = this.getResourceBundle().getText("Updated");
			var TrlrUpdtMsg = this.getResourceBundle().getText("TrlrUpdt");
			var TrlrMsg = this.getResourceBundle().getText("Trlr");
			var ClsdTrlrMsg = this.getResourceBundle().getText("ClsdTrlr");
			var PrintPickListMsg = this.getResourceBundle().getText("PrintPickListMsg");
			var oModel = this.getView().getModel("shipmentModel");
			var shipment = that.byId("ShipmentInput").getValue().trim();
			var trailer = that.byId("TrailerInput").getValue().trim();
			var oPayload = {};
			oPayload.Shpmnt = that.byId("ShipmentInput").getValue().trim();
			oPayload.Signi = that.byId("DoorInput").getValue().trim();
			oPayload.Trailer = trailer;
			oPayload.Seal = that.byId("SealInput").getValue().trim();
			oPayload.Scacd = that.byId("ScacInput").getValue().trim();

			if (oEvent !== undefined) {
				if (oEvent.getParameter("id").split("--")[2] === "UpdateShipment") {
					oPayload.Action = "U";
					status = "U";
				} else if (oEvent.getParameter("id").split("--")[2] === "CloseTrailer") {
					oPayload.Action = "C";
					status = "C";
				} else {
					oPayload.Action = "P";
					status = "P";
				}
			} else {
				oPayload.Action = "P";
				status = "P";
			}
			that.hideMessageStrip();
			sap.ui.core.BusyIndicator.show();
			oModel.update("/ShipmentSet(Shpmnt='" + shipment + "')", oPayload, {
				method: "PUT",
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide(0);
					if (response.statusCode === "204") {
						if (status === "U") {
							that.onInputShipmentSubmit();
							//var TO;
							//alert(TO);
							successMsg = ShipmentMsg + " - " + shipment + " " + UpdatedMsg + ".";
							that.trailerStatus = "";
							that.updateMessageStrip(sap.ui.core.MessageType.Success, successMsg);
							that.updatePostingList(successMsg, "", "", "");
							that.onFocus("HUInput_0");

						} else if (status === "C") {
							that.trailerStatus = "C";
							successMsg = TrlrMsg + " " + trailer + ClsdTrlrMsg + "  " + shipment + ".";
							that.updateMessageStrip(sap.ui.core.MessageType.Success, successMsg);
							that.updatePostingList(successMsg, "", "", "");
							that.onClear("closeTrailer");
							that.onFocus("ShipmentInput");
						} else if (status === "P") {
							that.onInputShipmentSubmit();
							that.trailerStatus = "P";
							successMsg = PrintPickListMsg;
							if (oEvent !== undefined) {
								that.updateMessageStrip(sap.ui.core.MessageType.Success, successMsg);
								that.updatePostingList(successMsg, "", "", "");
							} else {
								that.updateMessageStrip("Print", successMsg);
								that.updatePostingList(successMsg, "", "", "");
							}
							that.onFocus("HUInput_0");

						}
					}
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide(0);
					if (oEvent === undefined) {
						that.createNewErrorLog(oError, "PrintPickList");
					} else {
						that.createNewErrorLog(oError, ShipmentMsg + " : " + shipment);
					}
					that.onFocus("ShipmentInput");
				}
			});
		},

		onHU1Submit: function (oEvent) {
			var that = this;
			if (this.getView().byId("HUInput_0").getValue().trim() === "") {
				that.createNewErrorLog("HU", "HU : ");
				that.getView().byId("HUInput_0").setValueState("Error");
				that.onFocus("HUInput_0");
			} else {
				that.getView().byId("HUInput_0").setValueState("None");
				this.fnHUDetails("0");
			}
		},
		onHU2Submit: function (oEvent) {
			var that = this;
			var hu = this.getView().byId("HUInput_1").getValue().trim();
			that.getView().byId("HUInput_1").setValueState("None");
			that.hideMessageStrip();
			if (this.getView().byId("HUInput_1").getValue().trim() === "") {
				that.getView().byId("scanDoorInput_1").setEnabled(true);
				that.onFocus("scanDoorInput_1");
			} else if (hu === this.getView().byId("HUInput_0").getValue().trim()) {
				that.createNewErrorLog("Same-HU", "Handling Unit 1: " + hu);
				that.getView().byId("HUInput_1").setValueState("Error");
				that.onFocus("HUInput_1");
			} else {
				that.getView().byId("HUInput_1").setValueState("None");
				this.fnHUDetails("1");
			}
		},
		fnHUDetails: function (id) {
			var that = this;
			that.hideMessageStrip();
			var oModel = this.getView().getModel("shipmentModel");
			var shipment = this.getView().byId("ShipmentInput").getValue().trim();
			var oHU = this.getView().byId("HUInput_" + id).getValue().trim();
			var door = this.getView().byId("DoorInput").getValue().trim();
			var delivery = "",
				item = "";
			var selectedDelivery = this.getView().byId("huTable").getSelectedItem();
			if (selectedDelivery !== null) {
				if (selectedDelivery.getCells()[0].getText().includes(" -")) {
					delivery = selectedDelivery.getCells()[0].getText().split("-")[0].trim();
					//item = selectedDelivery.getCells()[0].getText().split("-")[1].trim();
					var itemData = selectedDelivery.getCells()[0].getText().split("-")[1].trim();
					item = itemData.split(" ")[0].trim();
				} else {
					delivery = "";
					item = "";
				}
			} else {
				delivery = "";
				item = "";
			}
			sap.ui.core.BusyIndicator.show();
			var uriString = "";
			if (id === "0") {
				uriString = "/PostHuSet(Exidv1='" + oHU + "',Shpmnt='" + shipment + "',Delivery='" + delivery + "',Item='" + item + "',Signi='" +
					door + "')";
			} else {
				uriString = "/PostHuSet(Exidv2='" + oHU + "',Shpmnt='" + shipment + "',Delivery='" + delivery + "',Item='" + item + "',Signi='" +
					door + "')";
			}
			oModel.read(uriString, {
				context: true,
				async: false,
				success: function (oData) {
					sap.ui.core.BusyIndicator.hide(0);
					//	MessageBox.show(JSON.stringify(oData));
					that.getView().byId("UnloadHU").setEnabled(false);
					that.getView().byId("CreateTo").setEnabled(false);
					that.getView().byId("UpdateShipment").setEnabled(false);
					that.getView().byId("CloseTrailer").setEnabled(false);
					//that.getView().byId("LineInput").setEnabled(false);
					that.getView().byId("DoorInput").setEnabled(false);
					that.getView().byId("ScacInput").setEnabled(false);
					that.getView().byId("SealInput").setEnabled(false);
					that.getView().byId("TrailerInput").setEnabled(false);
					
					that.getView().byId("refreshShipment").setEnabled(false);
					that.getView().byId("scanDoorInput_1").setEnabled(true);

					if (id == "0") {
						that.getView().byId("maxInput_" + id).setValue(oData.Max1);
						that.getView().byId("topickInput_" + id).setValue(oData.ToPick1);
						that.getView().byId("MaterialInput_" + id).setValue(oData.Material1);
						that.getView().byId("batchInput_" + id).setValue(oData.Batch1);
						that.getView().byId("qtyInput_" + id).setValue(oData.Qty1);
						that.getView().byId("HUInput_1").setEnabled(true);
						//that.getView().byId("Pick").setEnabled(true);
						that.onFocus("HUInput_1");
					} else {

						that.getView().byId("maxInput_" + id).setValue(oData.Max2);
						that.getView().byId("topickInput_" + id).setValue(oData.ToPick2);
						that.getView().byId("MaterialInput_" + id).setValue(oData.Material2);
						that.getView().byId("batchInput_" + id).setValue(oData.Batch2);
						that.getView().byId("qtyInput_" + id).setValue(oData.Qty2);

						that.onFocus("scanDoorInput_1");
					}
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide(0);
					that.createNewErrorLog(oError, "HU : " + oHU);
					that.onFocus("HUInput_" + id);
					that.getView().byId("HUInput_" + id).setValueState("None");

				}
			});
		},
		onReset: function (oEvent) {
			var hu = this.getView().byId("HUInput_0").getValue().trim();
			if (hu === "") {
				this.onClear("clear");

			} else {
				this.onClear("hu");
			}

		},

		onUpdateFinished: function (oEvent) {
			var that = this;
			var oTable = this.getView().byId("huTable");
			var aItems = oTable.getItems();
			if (aItems && aItems.length > 0) {
				for (var i = 0; i < aItems.length; i++) {
					var aCells = aItems[i].getCells();
					if (aCells[0].getText().includes(" -")) {
						//aItems[i].removeStyleClass("whiteBackground");
						//aItems[i].removeStyleClass("greenBackground");
						aItems[i].removeStyleClass("darkYellowBackground");
						aItems[i].addStyleClass("yellowBackground");
						//sap.ui.getCore().byId("button1").setVisible(false);
						aItems[i].getList().getItems()[i].getCells()[0].addStyleClass("deliveryBold");
						aItems[i].getList().getItems()[i].getCells()[1].addStyleClass("deliveryBold");
					} else {
						aItems[i].removeStyleClass("darkYellowBackground");
						aItems[i].removeStyleClass("yellowBackground");
						aItems[i].getList().getItems()[i].getCells()[0].removeStyleClass("deliveryBold");
						aItems[i].getList().getItems()[i].getCells()[1].removeStyleClass("deliveryBold");
					}

				}
			}
		},
		onPick: function () {
			var that = this;
			var oTO1 = "",
				oTO2 = "";
			var successMsg = "";
			var oModel = this.getView().getModel("shipmentModel");
			var DoorMandatoryMsg = this.getResourceBundle().getText("DoorMandatory");
			var scanDoorMsg = this.getResourceBundle().getText("scanDoor");
			var picked = this.getResourceBundle().getText("picked");
			var HU = this.getResourceBundle().getText("HU");
			var oPayload = {};
			var Qty1 = this.getView().byId("qtyInput_0").getValue().trim();
			var Qty2 = this.getView().byId("qtyInput_1").getValue().trim();
			var hu1 = this.getView().byId("HUInput_0").getValue().trim();
			var hu2 = this.getView().byId("HUInput_1").getValue().trim();
			var door = this.getView().byId("scanDoorInput_1").getValue().trim();
			var shipment = this.getView().byId("ShipmentInput").getValue().trim();
			that.hideMessageStrip();
			if (this.getView().byId("scanDoorInput_1").getValue() === "") {
				MessageBox.warning(DoorMandatoryMsg);
				that.onFocus("scanDoorInput_1");
				//that.getView().getModel("shipmentModel");
				return;
			} else {

				var delivery = "";
				var item = "";
				//var Delivery = delivery+"/"+item;
				var selectedDelivery = this.getView().byId("huTable").getSelectedItem();
				if (selectedDelivery !== null) {
					if (selectedDelivery.getCells()[0].getText().includes(" -")) {
						delivery = selectedDelivery.getCells()[0].getText().split("-")[0].trim();
						var itemData = selectedDelivery.getCells()[0].getText().split("-")[1].trim();
						item = itemData.split(" ")[0].trim();
					} else {
						delivery = "";
					}
				} else {
					delivery = "";
				}
				oPayload.Shpmnt = shipment;
				oPayload.Delivery = delivery;
				oPayload.Item = item;
				oPayload.Exidv1 = hu1;
				oPayload.Exidv2 = hu2;
				oPayload.Signi = door;
				sap.ui.core.BusyIndicator.show();
				oModel.create("/PostHuSet", oPayload, {
					success: function (oData, response) {

						var Delivery = "";
						sap.ui.core.BusyIndicator.hide(0);
						if (delivery !== "") {
							Delivery = delivery + "/" + item;
						} else {
							Delivery = "";
						}

						var msg = oData.Log1;
						var SuccessLog1 = HU + " " + hu1 + " " + picked;
						var SuccessLog2 = HU + " " + hu2 + " " + picked;

						for (var i = 0; i < that.oTODATA.length; i++) {
							if (that.oTODATA[i].HU === hu1) {
								oTO1 = that.oTODATA[i].TO;
								//							 	alert(JSON.stringify(that.oTODATA[i]));
							}
							if (hu2 !== "") {
								if (that.oTODATA[i].HU === hu2)
									oTO2 = that.oTODATA[i].TO;
							}
						}

						if (oData.LogType1 === "S" && oData.LogType2 === "") {

							that.onInputShipmentSubmit();
							that.updatePostingList(SuccessLog1, Qty1, oTO1, Delivery);
							that.updateMessageStrip(sap.ui.core.MessageType.Success, msg);
							that.onClear("onPick");
						} else if (oData.LogType1 === "S" && oData.LogType2 === "S") {
							that.onInputShipmentSubmit();
							that.updatePostingList(SuccessLog1, Qty1, oTO1, Delivery);
							that.updatePostingList(SuccessLog2, Qty2, oTO2, Delivery);
							successMsg = oData.Log1 + "  " + oData.Log2;
							that.updateMessageStrip(sap.ui.core.MessageType.Success, successMsg);
							that.onClear("onPick");
						} else if (oData.LogType1 === "S" && oData.LogType2 === "E") {
							that.onInputShipmentSubmit();
							that.updatePostingList(SuccessLog1, Qty1, oTO1, Delivery);
							that.updateMessageStrip(sap.ui.core.MessageType.Success, oData.Log1);
							that.createNewErrorLog("Post Error Pick", oData.Log2);
							that.updateMessageStrip("", oData.Log2);
							that.onClear("onPick");
						} else if (oData.LogType1 === "E" && oData.LogType2 === "S") {
							that.onInputShipmentSubmit();
							that.updatePostingList(SuccessLog2, Qty2, oTO2, Delivery);
							that.createNewErrorLog("Post Error Pick", oData.Log1);
							that.updateMessageStrip(sap.ui.core.MessageType.Success, oData.Log2);
							that.updateMessageStrip("", oData.Log1);
							that.onClear("onPick");
						} else if (oData.LogType1 === "E" && oData.LogType2 === "") {
							that.createNewErrorLog("Post Error Pick", oData.Log1);
							successMsg = oData.Log1;
							that.updateMessageStrip(sap.ui.core.MessageType.Error, successMsg);
						} else if (oData.LogType1 === "E" && oData.LogType2 === "E") {
							that.createNewErrorLog("Post Error Pick", oData.Log1 + " " + oData.Log2);
							successMsg = oData.Log1 + "  " + oData.Log2;
							that.updateMessageStrip(sap.ui.core.MessageType.Error, successMsg);
						} else {
							that.updateMessageStrip(sap.ui.core.MessageType.Error, msg);
						}
						that.onFocus("scanDoorInput_1");
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide(0);
						that.createNewErrorLog(oError, scanDoorMsg + " : " + door);
						that.onFocus("scanDoorInput_1");
					}
				});
			}
		},
		onPrintPicklist: function () {
			this.onUpdateShipment();
		},
		onLiveChangeList: function (oEvent) {
			// build filter array
			var like = oEvent.getSource().getValue();
			var binding = this.getView().byId("huTable").getBinding("items");
			var filters = [
				new sap.ui.model.Filter("Delivery", sap.ui.model.FilterOperator.Contains, like),
				new sap.ui.model.Filter("Vsolm", sap.ui.model.FilterOperator.Contains, like),
				new sap.ui.model.Filter("Charg", sap.ui.model.FilterOperator.Contains, like),
				new sap.ui.model.Filter("Vlenr", sap.ui.model.FilterOperator.Contains, like)
				// Add additional filters  
			];
			var oFilter = new sap.ui.model.Filter({
				aFilters: filters,
				bAnd: false,
				_bMultiFilter: true
			}); // true = AND, false = OR  

			binding.filter(oFilter);
			this.getView().byId("huTable").removeSelections(true);
		//	this.OnSelectionChange();
		},
		OnSelectionChange: function (oEvent) {
			var that = this;
			var oTable = this.getView().byId("huTable");
			var aItems = oTable.getItems();
			if (aItems && aItems.length > 0) {
				for (var i = 0; i < aItems.length; i++) {
					var aCells = aItems[i].getCells();
					if (aCells[0].getText().includes(" -")) {
						if (aCells[0].getText().trim() === oTable.getSelectedItem().getCells()[0].getText().trim()) {
							aItems[i].removeStyleClass("yellowBackground");
							aItems[i].addStyleClass("darkYellowBackground");
						} else {
							aItems[i].removeStyleClass("darkYellowBackground");
							aItems[i].addStyleClass("yellowBackground");
						}
						aItems[i].getList().getItems()[i].getCells()[0].addStyleClass("deliveryBold");
						aItems[i].getList().getItems()[i].getCells()[1].addStyleClass("deliveryBold");
					} else {
						aItems[i].removeStyleClass("darkYellowBackground");
						aItems[i].removeStyleClass("yellowBackground");
						aItems[i].getList().getItems()[i].getCells()[0].removeStyleClass("deliveryBold");
						aItems[i].getList().getItems()[i].getCells()[1].removeStyleClass("deliveryBold");
					}

				}
			}

		}
	});

});